package com.tasks.exceptions;

public class NotFoundException extends RuntimeException {
}
