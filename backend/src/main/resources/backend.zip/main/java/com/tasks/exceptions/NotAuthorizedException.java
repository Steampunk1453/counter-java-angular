package com.tasks.exceptions;

public class NotAuthorizedException extends RuntimeException {
}
